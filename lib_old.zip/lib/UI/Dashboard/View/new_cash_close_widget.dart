import 'dart:convert';

import 'package:flutter/services.dart';
import 'package:gmart/Constant/app_color.dart';
import 'package:gmart/Constant/app_strings.dart';
import 'package:gmart/Core/application_base.dart';
import 'package:gmart/UI/Dashboard/ViewModel/dashboard_view_model.dart';
import 'package:gmart/Utils/text_decorator.dart';

class NewCashCloseWidget extends StatefulWidget {
  final Future<void> Function(Map<String, dynamic> postData) onDone;

  const NewCashCloseWidget({super.key, required this.onDone});

  @override
  State<NewCashCloseWidget> createState() => _NewCashCloseWidgetState();
}

class _NewCashCloseWidgetState extends State<NewCashCloseWidget> {
  TextEditingController cashCtrl = TextEditingController();
  TextEditingController cardCtrl = TextEditingController();
  TextEditingController fiveCtrl = TextEditingController();
  TextEditingController tenCtrl = TextEditingController();
  TextEditingController fifCtrl = TextEditingController();
  TextEditingController hunCtrl = TextEditingController();
  TextEditingController notesCtrl = TextEditingController();
  TextEditingController selectedCtrl = TextEditingController();
  final cashForm = GlobalKey<FormState>();
  int length = 5;
  SharedPreferences? prefs;
  List<String> denominationList = [];
  final Map<String, TextEditingController> controllers = {};
  DashboardViewModel? model;

  @override
  void initState() {
    prefs = spEngine!.prefs;
    loadDenominations();
    super.initState();
  }

  @override
  void dispose() {
    controllers.forEach((_, controller) => controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BaseView<DashboardViewModel>(
      prepareModel: (model) {
        this.model = model;
        model.getCashDetails().then(
          (value) {
            // setState(() {
            //   cashCtrl.text = model.cashRegDetails!.totalCash ?? "";
            // });
          },
        );
      },
      builder: (context, model, child) {
        return Scaffold(
          appBar: AppBar(
            elevation: 0.0,
            titleSpacing: 0.0,
            backgroundColor: AppColor.primaryColor,
            systemOverlayStyle:
                SystemUiOverlayStyle(statusBarColor: AppColor.primaryColor),
            title: const Text("Cash Close"),
          ),
          body: model.state == ViewState.innerInActive
              ? const Center(
                  child: CircularProgressIndicator(),
                )
              : Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 15.0,
                      ),
                      width: MediaQuery.of(context).size.width / 2.5,
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Form(
                          key: cashForm,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              const SizedBox(
                                height: 15.0,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Total Cash Amount",
                                    style: TextStyle(
                                        color: AppColor.blackColor,
                                        fontSize: 20.0,
                                        fontWeight: FontWeight.w600),
                                  ),
                                  const SizedBox(
                                    height: 10.0,
                                  ),
                                  SizedBox(
                                    width: 250.0,
                                    child: TextFormField(
                                      readOnly: true,
                                      // enabled: false,
                                      controller: cashCtrl,
                                      onTap: () {
                                        setState(() {
                                          selectedCtrl = cashCtrl;
                                        });
                                      },
                                      onChanged: (value) {
                                        setState(() {});
                                      },
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return "Cash amount is required.";
                                        } else {
                                          return null;
                                        }
                                      },
                                      keyboardType:
                                          const TextInputType.numberWithOptions(
                                              decimal: true),
                                      inputFormatters: [
                                        FilteringTextInputFormatter.allow(
                                            RegExp(r'^\d*\.?\d{0,2}')),
                                      ],
                                      decoration: textDecorator(
                                          label: "Enter the cash amount",
                                          borderColor: Colors.orange,
                                          contentPadding:
                                              const EdgeInsets.symmetric(
                                                  horizontal: 15.0,
                                                  vertical: 10.0)),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 15.0,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Total Card Slips",
                                    style: TextStyle(
                                        color: AppColor.blackColor,
                                        fontSize: 20.0,
                                        fontWeight: FontWeight.w600),
                                  ),
                                  const SizedBox(
                                    height: 10.0,
                                  ),
                                  SizedBox(
                                    width: 250.0,
                                    child: TextFormField(
                                      controller: cardCtrl,
                                      readOnly: true,
                                      onTap: () {
                                        setState(() {
                                          selectedCtrl = cardCtrl;
                                        });
                                      },
                                      maxLength: 3,
                                      onChanged: (value) {
                                        setState(() {});
                                      },
                                      inputFormatters: [
                                        FilteringTextInputFormatter.digitsOnly
                                      ],
                                      decoration: textDecorator(
                                          label: "No.of.card slips",
                                          borderColor: Colors.orange,
                                          contentPadding:
                                              const EdgeInsets.symmetric(
                                                  horizontal: 15.0,
                                                  vertical: 10.0)),
                                    ),
                                  ),
                                ],
                              ),
                              const SizedBox(
                                height: 15.0,
                              ),
                              Text(
                                "Denominations",
                                style: TextStyle(
                                    color: AppColor.blackColor,
                                    fontSize: 20.0,
                                    fontWeight: FontWeight.w600),
                              ),
                              Column(
                                children: denominationList.asMap().entries.map(
                                  (e) {
                                    return Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Text(
                                          "X ${e.value} ${"= ${(double.parse(e.value ?? "0.00") * double.parse(controllers[e.value]!.text == "" ? "0.00" : controllers[e.value]!.text)).toStringAsFixed(2)}"}",
                                          style: TextStyle(
                                              color: AppColor.blackColor,
                                              fontWeight: FontWeight.w600,
                                              fontSize: 18.0),
                                        ),
                                        Container(
                                          width: 150.0,
                                          margin:
                                              const EdgeInsets.only(top: 5.0),
                                          child: TextFormField(
                                            maxLength: 3,
                                            readOnly: true,
                                            onChanged: (value) {
                                              setState(() {});
                                            },
                                            controller: controllers[e.value],
                                            onTap: () {
                                              setState(() {
                                                selectedCtrl =
                                                    controllers[e.value]!;
                                              });
                                            },
                                            // validator: (value) {
                                            //   if(value == null || value.isEmpty){
                                            //     return "\$5 is required.";
                                            //   }else{
                                            //     return null;
                                            //   }
                                            // },
                                            inputFormatters: [
                                              FilteringTextInputFormatter
                                                  .digitsOnly
                                            ],
                                            decoration: textDecorator(
                                                label:
                                                    "${denominationList[e.key]} X",
                                                borderColor: Colors.orange,
                                                contentPadding:
                                                    const EdgeInsets.symmetric(
                                                        horizontal: 15.0,
                                                        vertical: 10.0)),
                                          ),
                                        ),
                                      ],
                                    );
                                  },
                                ).toList(),
                              )
                            ],
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: MediaQuery.of(context).size.width / 2.5,
                      child: Column(
                        children: [
                          /*Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 20.0,
                    ),
                    Text(
                      "Payments Notes",
                      style: TextStyle(
                          color: AppColor.blackColor,
                          fontSize: 20.0,
                          fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(
                      height: 15.0,
                    ),
                    TextFormField(
                      controller: notesCtrl,
                      maxLines: 6,
                      decoration: textDecorator(label: "Payments noes"),
                    ),
                  ],
                ),*/
                          const SizedBox(
                            height: 15.0,
                          ),
                          Column(
                            children: [
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  buttonWidget(
                                    title: "7",
                                    onTap: () {
                                      if (selectedCtrl.text.length < length) {
                                        setState(() {
                                          selectedCtrl.text =
                                              "${selectedCtrl.text}7";
                                        });
                                      }
                                    },
                                  ),
                                  buttonWidget(
                                    title: "8",
                                    onTap: () {
                                      if (selectedCtrl.text.length < length) {
                                        setState(() {
                                          selectedCtrl.text =
                                              "${selectedCtrl.text}8";
                                        });
                                      }
                                    },
                                  ),
                                  buttonWidget(
                                    title: "9",
                                    onTap: () {
                                      if (selectedCtrl.text.length < length) {
                                        setState(() {
                                          selectedCtrl.text =
                                              "${selectedCtrl.text}9";
                                        });
                                      }
                                    },
                                  )
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  buttonWidget(
                                    title: "4",
                                    onTap: () {
                                      if (selectedCtrl.text.length < length) {
                                        setState(() {
                                          selectedCtrl.text =
                                              "${selectedCtrl.text}4";
                                        });
                                      }
                                    },
                                  ),
                                  buttonWidget(
                                    title: "5",
                                    onTap: () {
                                      if (selectedCtrl.text.length < length) {
                                        setState(() {
                                          selectedCtrl.text =
                                              "${selectedCtrl.text}5";
                                        });
                                      }
                                    },
                                  ),
                                  buttonWidget(
                                    title: "6",
                                    onTap: () {
                                      if (selectedCtrl.text.length < length) {
                                        setState(() {
                                          selectedCtrl.text =
                                              "${selectedCtrl.text}6";
                                        });
                                      }
                                    },
                                  )
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  buttonWidget(
                                    title: "1",
                                    onTap: () {
                                      if (selectedCtrl.text.length < length) {
                                        setState(() {
                                          selectedCtrl.text =
                                              "${selectedCtrl.text}1";
                                        });
                                      }
                                    },
                                  ),
                                  buttonWidget(
                                    title: "2",
                                    onTap: () {
                                      if (selectedCtrl.text.length < length) {
                                        setState(() {
                                          selectedCtrl.text =
                                              "${selectedCtrl.text}2";
                                        });
                                      }
                                    },
                                  ),
                                  buttonWidget(
                                    title: "3",
                                    onTap: () {
                                      if (selectedCtrl.text.length < length) {
                                        setState(() {
                                          selectedCtrl.text =
                                              "${selectedCtrl.text}3";
                                        });
                                      }
                                    },
                                  )
                                ],
                              ),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  buttonWidget(
                                    title: "Clear",
                                    onTap: () {
                                      setState(() {
                                        selectedCtrl.text = "";
                                      });
                                    },
                                  ),
                                  buttonWidget(
                                    title: "0",
                                    onTap: () {
                                      if (selectedCtrl.text.length < length) {
                                        setState(() {
                                          selectedCtrl.text =
                                              "${selectedCtrl.text}0";
                                        });
                                      }
                                    },
                                  ),
                                  buttonWidget(
                                    title: "Del",
                                    onTap: () {
                                      if (selectedCtrl.text.isNotEmpty) {
                                        setState(() {
                                          selectedCtrl.text = selectedCtrl.text
                                              .substring(0,
                                                  selectedCtrl.text.length - 1);
                                        });
                                      }
                                    },
                                  ),
                                  /*buttonWidget(
                              title: ".",
                              onTap: () {
                                if (selectedCtrl.text.isNotEmpty) {
                                  selectedCtrl.text = "${selectedCtrl.text}.";
                                } else {
                                  selectedCtrl.text = "0.";
                                }
                              },
                            ),*/
                                ],
                              ),
                            ],
                          ),
                          /*Expanded(
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SingleChildScrollView(
                        physics: const NeverScrollableScrollPhysics(),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              width: 250.0,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Total Cash",
                                    style: TextStyle(
                                        color: AppColor.blackColor,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 18.0),
                                  ),
                                  Text(
                                    "= ${double.parse(cashCtrl.text == "" ? "0.00" : cashCtrl.text ?? "0.00").toStringAsFixed(2)}",
                                    style: TextStyle(
                                        color: AppColor.blackColor,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14.0),
                                  )
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 8.0,
                            ),
                            SizedBox(
                              width: 250.0,
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    "Total Card Slip",
                                    style: TextStyle(
                                        color: AppColor.blackColor,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 18.0),
                                  ),
                                  Text(
                                    "= ${double.parse(cardCtrl.text == "" ? "0.00" : cardCtrl.text ?? "0.00").toStringAsFixed(2)}",
                                    style: TextStyle(
                                        color: AppColor.blackColor,
                                        fontWeight: FontWeight.w600,
                                        fontSize: 14.0),
                                  )
                                ],
                              ),
                            ),
                            const SizedBox(
                              height: 8.0,
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: denominationList.asMap().entries.map(
                                (e) {
                                  return SizedBox(
                                    width: 250.0,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const SizedBox(
                                          height: 4.0,
                                        ),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Text(
                                              "X ${e.value}",
                                              style: TextStyle(
                                                  color: AppColor.blackColor,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 18.0),
                                            ),
                                            Text(
                                              "= ${(double.parse(e.value ?? "0.00") * double.parse(controllers[e.value]!.text == "" ? "0.00" : controllers[e.value]!.text)).toStringAsFixed(2)}",
                                              style: TextStyle(
                                                  color: AppColor.blackColor,
                                                  fontWeight: FontWeight.w600,
                                                  fontSize: 14.0),
                                            )
                                          ],
                                        ),
                                        const SizedBox(
                                          height: 4.0,
                                        ),
                                      ],
                                    ),
                                  );
                                },
                              ).toList(),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(
                        width: 15.0,
                      ),
                      Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              buttonWidget(
                                title: "7",
                                onTap: () {
                                  if (selectedCtrl.text.length < length) {
                                    setState(() {
                                      selectedCtrl.text =
                                          "${selectedCtrl.text}7";
                                    });
                                  }
                                },
                              ),
                              buttonWidget(
                                title: "8",
                                onTap: () {
                                  if (selectedCtrl.text.length < length) {
                                    setState(() {
                                      selectedCtrl.text =
                                          "${selectedCtrl.text}8";
                                    });
                                  }
                                },
                              ),
                              buttonWidget(
                                title: "9",
                                onTap: () {
                                  if (selectedCtrl.text.length < length) {
                                    setState(() {
                                      selectedCtrl.text =
                                          "${selectedCtrl.text}9";
                                    });
                                  }
                                },
                              )
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              buttonWidget(
                                title: "4",
                                onTap: () {
                                  if (selectedCtrl.text.length < length) {
                                    setState(() {
                                      selectedCtrl.text =
                                          "${selectedCtrl.text}4";
                                    });
                                  }
                                },
                              ),
                              buttonWidget(
                                title: "5",
                                onTap: () {
                                  if (selectedCtrl.text.length < length) {
                                    setState(() {
                                      selectedCtrl.text =
                                          "${selectedCtrl.text}5";
                                    });
                                  }
                                },
                              ),
                              buttonWidget(
                                title: "6",
                                onTap: () {
                                  if (selectedCtrl.text.length < length) {
                                    setState(() {
                                      selectedCtrl.text =
                                          "${selectedCtrl.text}6";
                                    });
                                  }
                                },
                              )
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              buttonWidget(
                                title: "1",
                                onTap: () {
                                  if (selectedCtrl.text.length < length) {
                                    setState(() {
                                      selectedCtrl.text =
                                          "${selectedCtrl.text}1";
                                    });
                                  }
                                },
                              ),
                              buttonWidget(
                                title: "2",
                                onTap: () {
                                  if (selectedCtrl.text.length < length) {
                                    setState(() {
                                      selectedCtrl.text =
                                          "${selectedCtrl.text}2";
                                    });
                                  }
                                },
                              ),
                              buttonWidget(
                                title: "3",
                                onTap: () {
                                  if (selectedCtrl.text.length < length) {
                                    setState(() {
                                      selectedCtrl.text =
                                          "${selectedCtrl.text}3";
                                    });
                                  }
                                },
                              )
                            ],
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              buttonWidget(
                                title: "Clear",
                                onTap: () {
                                  setState(() {
                                    selectedCtrl.text = "";
                                  });
                                },
                              ),
                              buttonWidget(
                                title: "0",
                                onTap: () {
                                  if (selectedCtrl.text.length < length) {
                                    setState(() {
                                      selectedCtrl.text =
                                          "${selectedCtrl.text}0";
                                    });
                                  }
                                },
                              ),
                              buttonWidget(
                                title: "Del",
                                onTap: () {
                                  if (selectedCtrl.text.isNotEmpty) {
                                    setState(() {
                                      selectedCtrl.text = selectedCtrl.text
                                          .substring(
                                              0, selectedCtrl.text.length - 1);
                                    });
                                  }
                                },
                              ),
                              */
                          /*buttonWidget(
                              title: ".",
                              onTap: () {
                                if (selectedCtrl.text.isNotEmpty) {
                                  selectedCtrl.text = "${selectedCtrl.text}.";
                                } else {
                                  selectedCtrl.text = "0.";
                                }
                              },
                            ),*/
                          /*
                            ],
                          ),
                        ],
                      )
                    ],
                  ),
                ),*/
                          Container(
                            margin: const EdgeInsets.all(15.0),
                            child: Row(
                              children: [
                                Expanded(
                                  child: InkResponse(
                                    radius: 5.0,
                                    onTap: () {
                                      if (cashForm.currentState!.validate()) {
                                        final Map<String, dynamic> payload =
                                            {}; // use dynamic so we can store null
                                        controllers.forEach(
                                            (denomination, controller) {
                                          String value = controller.text.trim();
                                          payload[denomination] =
                                              value.isEmpty ? null : value;
                                        });
                                        Map<String, dynamic> postData = {
                                          "closing_amount":
                                              cashCtrl.text.isEmpty
                                                  ? 0
                                                  : num.parse(cashCtrl.text),
                                          "total_card_slips":
                                              cardCtrl.text.isEmpty
                                                  ? 0
                                                  : int.parse(cardCtrl.text),
                                          "total_cheques": 0,
                                          "closing_note": notesCtrl.text,
                                          /* "denominations": {
                          "5": int.parse(
                              fiveCtrl.text.isEmpty ? "0" : fiveCtrl.text),
                          "10": int.parse(
                              tenCtrl.text.isEmpty ? "0" : tenCtrl.text),
                          "50": int.parse(
                              fifCtrl.text.isEmpty ? "0" : fifCtrl.text),
                          "100":
                              int.parse(hunCtrl.text.isEmpty ? "0" : hunCtrl.text)
                        }*/
                                          "denominations": payload
                                        };
                                        widget.onDone(postData);
                                      }
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 20.0),
                                      decoration: BoxDecoration(
                                        color: AppColor.primaryColor,
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                      ),
                                      child: Text(
                                        "Cash Close",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: AppColor.whiteColor,
                                            fontSize: 20.0,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                ),
                                const SizedBox(
                                  width: 15.0,
                                ),
                                Expanded(
                                  child: InkResponse(
                                    radius: 5.0,
                                    onTap: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Container(
                                      padding: const EdgeInsets.symmetric(
                                          vertical: 20.0),
                                      decoration: BoxDecoration(
                                        color: Colors.red,
                                        borderRadius:
                                            BorderRadius.circular(8.0),
                                      ),
                                      child: Text(
                                        "Back",
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: AppColor.whiteColor,
                                            fontSize: 20.0,
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
        );
      },
    );
  }

  Widget buttonWidget(
      {required String title,
      Color? btnColor,
      Color? textColor,
      Function()? onTap}) {
    return Expanded(
      child: InkResponse(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(3.0),
          child: Container(
            // width: MediaQuery.of(context).size.width * 0.07,
            padding: const EdgeInsets.symmetric(vertical: 25.0),
            alignment: Alignment.center,
            decoration: BoxDecoration(
                // color: btnColor ?? Colors.black12,
                color: Colors.blueAccent,
                borderRadius: BorderRadius.circular(8.0)),
            child: Text(
              title.toUpperCase(),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  color: textColor ?? AppColor.whiteColor,
                  fontSize: 20.0,
                  fontWeight: FontWeight.w800),
            ),
          ),
        ),
      ),
    );
  }

  void loadDenominations() {
    String? permittedList = prefs!.getString(AppStrings.denominationList);
    if (permittedList != null) {
      List<dynamic> decodedList = jsonDecode(permittedList);
      List<String> mainList = decodedList.map((e) => e.toString()).toList();
      setState(() {
        denominationList = mainList;
      });
    }
    for (var denomination in denominationList) {
      controllers[denomination] = TextEditingController();
    }
  }
}

import 'dart:convert';
import 'dart:io';
import 'package:excel/excel.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:gmart/Constant/app_color.dart';
import 'package:gmart/Constant/app_strings.dart';
import 'package:gmart/Core/Engine/database_engine.dart';
import 'package:gmart/Core/application_base.dart';
import 'package:gmart/UI/Login/Model/login_response_model.dart';
import 'package:gmart/UI/Login/ViewModel/login_view_model.dart';
import 'package:gmart/Utils/loading_dialog_box.dart';
import 'package:gmart/Utils/text_decorator.dart';
import 'package:sqflite/sqflite.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  LoginViewModel? model;
  bool isPass = true;
  final keyLoader = GlobalKey<State>();
  final formKey = GlobalKey<FormState>();
  final cashFormKey = GlobalKey<FormState>();
  TextEditingController emailCtrl = TextEditingController();
  TextEditingController cashCtrl = TextEditingController();
  TextEditingController locationCtrl = TextEditingController();
  TextEditingController pwdCtrl = TextEditingController();
  DateTime? currentBackPressTime;
  int locationId = 0;
  bool isCashEnable = false, isLocation = false;
  SharedPreferences? pref;
  List<Locations> localLocation = [];

  @override
  void initState() {
    isLoad();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BaseView<LoginViewModel>(
      prepareModel: (model) {
        this.model = model;
      },
      builder: (context, model, child) {
        return PopScope(
          canPop: false,
          onPopInvoked: (didPop) {
            if (!didPop) {
              DateTime now = DateTime.now();
              if (currentBackPressTime == null ||
                  now.difference(currentBackPressTime!) >
                      const Duration(seconds: 2)) {
                currentBackPressTime = DateTime.now();
                Fluttertoast.showToast(
                  msg: "Press again to exit",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.BOTTOM,
                  timeInSecForIosWeb: 1,
                  backgroundColor: AppColor.primaryColor,
                  textColor: Colors.white,
                  fontSize: 16.0,
                );
              } else {
                Navigator.of(context).pop();
              }
            }
          },
          child: Scaffold(
            body: isCashEnable ? cashSection() : loginSection(),
          ),
        );
      },
    );
  }

  Widget loginSection() {
    return Form(
      key: formKey,
      child: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset("assets/images/logo.png"),
            const SizedBox(
              height: 15.0,
            ),
            Text(
              "Sign in wth an email and password to continue.",
              style: TextStyle(color: AppColor.primaryColor),
            ),
            const SizedBox(
              height: 15.0,
            ),
            SizedBox(
              width: 350.0,
              child: TextFormField(
                controller: emailCtrl,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Username is required.";
                  } else {
                    return null;
                  }
                },
                decoration: textDecorator(label: "username"),
              ),
            ),
            const SizedBox(
              height: 15.0,
            ),
            SizedBox(
              width: 350.0,
              child: TextFormField(
                controller: pwdCtrl,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Password is required.";
                  } else {
                    return null;
                  }
                },
                obscureText: isPass,
                decoration: textDecorator(
                    label: "Password",
                    suffixIcon: InkResponse(
                      onTap: () {
                        setState(() {
                          isPass = !isPass;
                        });
                      },
                      child: Icon(
                        isPass ? Icons.visibility_off_sharp : Icons.visibility,
                        size: 20.0,
                      ),
                    )),
              ),
            ),
            const SizedBox(
              height: 15.0,
            ),
            ElevatedButton(
                onPressed: () async {
                  validateInput(context);
                },
                child: const Text("Login"))
          ],
        ),
      ),
    );
  }

  Widget cashSection() {
    return Form(
      key: formKey,
      child: Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset("assets/images/logo.png"),
            const SizedBox(
              height: 15.0,
            ),
            Visibility(
              visible: !isLocation,
              child: SizedBox(
                width: 350.0,
                child: DropdownButtonFormField(
                  // value: locationCtrl.text,
                  decoration: textDecorator(),
                  hint: const Text("Select location"),
                  alignment: Alignment.center,
                  items: localLocation.asMap().entries.map(
                    (e) {
                      return DropdownMenuItem<String>(
                          value: e.value.name, child: Text(e.value.name ?? ""));
                    },
                  ).toList(),
                  /*onChanged: (value) async {
                    List<Locations> selected = localLocation
                        .where((element) => element.name == value)
                        .toList();
                    if (selected.isNotEmpty) {
                      if (selected[0].cashRegister != null) {
                        bool isOk = await startImportAndNavigate();
                        if (isOk) {
                          await pref!.setInt(AppStrings.cashId,
                              selected[0].cashRegister!.id ?? 0);
                          await pref!.setInt(AppStrings.isCash, 1);
                          await pref!.setString(AppStrings.paymentList,
                              jsonEncode(selected[0].payment ?? []));
                          await pref!.setString(AppStrings.qrCodeImage,
                              selected[0].media!.displayUrl ?? "");
                          await pref!.setString(
                              AppStrings.selectedHub, selected[0].name ?? "");
                          await pref!.setString(AppStrings.selectedAddress,
                              "${selected[0].city ?? ""},${selected[0].country ?? ""} - ${selected[0].zipCode ?? ""}");
                          await pref!.setInt(
                              AppStrings.businessLocations,
                              int.parse(selected[0]
                                  .cashRegister!
                                  .locationId
                                  .toString()));
                        }
                      } else {
                        List<Payment> payment = selected[0].payment ?? [];
                        await pref!.setString(
                            AppStrings.paymentList, jsonEncode(payment));
                        await pref!.setString(
                            AppStrings.selectedHub, selected[0].name ?? "");
                        await pref!.setString(AppStrings.selectedAddress,
                            "${selected[0].city ?? ""},${selected[0].country ?? ""} - ${selected[0].zipCode ?? ""}");
                        await pref!.setString(AppStrings.qrCodeImage,
                            selected[0].media!.displayUrl ?? "");
                        setState(() {
                          locationCtrl.text = selected[0].name ?? "";
                          locationId = selected[0].id ?? 0;
                        });
                      }
                    }
                  },*/
                  onChanged: (value) async {
                    // try {
                    final selected =
                        localLocation.where((e) => e.name == value).toList();

                    if (selected.isEmpty) return;

                    setState(() {
                      locationCtrl.text = selected[0].name ?? "";
                      locationId = selected[0].id ?? 0;
                    });

                    // ✅ Show loader
                    LoadingDialogBox()
                        .loading(context, keyLoader, msg: "Please wait");
                    await Future.delayed(Duration.zero);

                    final success = await _handleLocationSelection(selected[0]);
                    // ✅ Always close loader safely
                    if (mounted &&
                        Navigator.of(context, rootNavigator: true).canPop()) {
                      Navigator.of(context, rootNavigator: true).pop();
                    }

                    if (!success) {
                      if (mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text("Data import failed")),
                        );
                      }
                      return;
                    }

                    // 🚀 Navigate only on success
                    if (!mounted) return;
                    await Navigator.of(context).pushNamedAndRemoveUntil(
                      "/Dashboard",
                      (route) => false,
                    );
                    // } catch (e) {
                    //   Navigator.of(keyLoader.currentContext!,
                    //           rootNavigator: true)
                    //       .pop();
                    //   ScaffoldMessenger.of(context).showSnackBar(
                    //     SnackBar(
                    //         content:
                    //             Text("Data import failed : ${e.toString()}")),
                    //   );
                    // }
                  },
                ),
              ),
            ),
            const SizedBox(
              height: 15.0,
            ),
            SizedBox(
              width: 350.0,
              child: TextFormField(
                controller: cashCtrl,
                keyboardType:
                    const TextInputType.numberWithOptions(decimal: true),
                inputFormatters: [
                  // FilteringTextInputFormatter.digitsOnly,
                  FilteringTextInputFormatter.allow(RegExp(r'^\d+\.?\d{0,2}')),
                ],
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Cash is required.";
                  } else {
                    return null;
                  }
                },
                decoration: textDecorator(label: "Enter the cash amount"),
              ),
            ),
            const SizedBox(
              height: 15.0,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                  onPressed: () async {
                    validateCashInput(context);
                  },
                  child: const Text("Register Cash"),
                ),
                const SizedBox(
                  width: 15.0,
                ),
                ElevatedButton(
                    onPressed: () async {
                      await pref!.clear();
                      Navigator.of(context).pushNamedAndRemoveUntil(
                        "/",
                        (route) => false,
                      );
                    },
                    child: const Text("Logout")),
              ],
            )
          ],
        ),
      ),
    );
  }

  Future<bool> _handleLocationSelection(Locations location) async {
    try {
      if (location.cashRegister == null) {
        return false;
      }

      final isOk = await startImportAndNavigate();
      if (!isOk) return false;

      await pref!.setInt(AppStrings.cashId, location.cashRegister!.id ?? 0);
      await pref!.setInt(AppStrings.isCash, 1);
      await pref!.setString(
          AppStrings.paymentList, jsonEncode(location.payment ?? []));
      await pref!
          .setString(AppStrings.qrCodeImage, location.media?.displayUrl ?? "");
      await pref!.setString(AppStrings.selectedHub, location.name ?? "");
      await pref!.setString(
        AppStrings.selectedAddress,
        "${location.city ?? ""},${location.country ?? ""} - ${location.zipCode ?? ""}",
      );
      await pref!.setInt(
        AppStrings.businessLocations,
        int.parse(location.cashRegister!.locationId.toString()),
      );

      return true;
    } catch (e) {
      debugPrint("❌ Location selection error: $e");
      return false;
      // throw Exception(e.toString());
    }
  }

  void validateInput([BuildContext? context]) async {
    if (formKey.currentState!.validate()) {
      await model!
          .userAuth(
              email: emailCtrl.text,
              password: pwdCtrl.text,
              context: context!,
              key: keyLoader)
          .then(
        (value) async {
          if (value) {
            await Future.delayed(const Duration(seconds: 1));
            bool result =
                await model!.getExcel(context: context, key: keyLoader);
            if (result) {
              if (model!.locations.length == 1) {
                await Future.delayed(const Duration(seconds: 1));
                bool isOk = await startImportAndNavigate();
                if (isOk) {
                  if (model!.locations[0].cashRegister != null) {
                    await pref!.setBool(AppStrings.isLogIn, true);
                    await pref!.setInt(AppStrings.cashId,
                        model!.locations[0].cashRegister!.id ?? 0);
                    await pref!.setInt(
                        AppStrings.businessLocations,
                        int.parse(model!.locations[0].cashRegister!.locationId
                            .toString()));
                    await pref!.setString(AppStrings.qrCodeImage,
                        model!.locations[0].media!.displayUrl ?? "");
                    List<Payment> payment = model!.locations[0].payment ?? [];
                    await pref!
                        .setString(AppStrings.paymentList, jsonEncode(payment));
                    await pref!.setString(
                        AppStrings.selectedHub, model!.locations[0].name ?? "");
                    await pref!.setString(
                        AppStrings.selectedAddress,
                        // "${},"
                        "${model!.locations[0].city ?? ""},${model!.locations[0].country ?? ""} - ${model!.locations[0].zipCode ?? ""}");
                    await Navigator.of(context).pushNamedAndRemoveUntil(
                      "/Dashboard",
                      (route) => false,
                    );
                  } else {
                    await pref!.setBool(AppStrings.isLogIn, true);
                    await pref!.setString(AppStrings.paymentList,
                        model!.locations[0].media!.displayUrl ?? "");
                    List<Payment> payment = model!.locations[0].payment ?? [];
                    await pref!
                        .setString(AppStrings.paymentList, jsonEncode(payment));
                    await pref!.setString(
                        AppStrings.selectedHub, model!.locations[0].name ?? "");
                    await pref!.setString(
                        AppStrings.selectedAddress,
                        // "${},"
                        "${model!.locations[0].city ?? ""},${model!.locations[0].country ?? ""} - ${model!.locations[0].zipCode ?? ""}");
                    setState(() {
                      locationId = model!.locations[0].id ?? 0;
                      isCashEnable = true;
                      isLocation = true;
                    });
                  }
                }
              } else {
                await pref!.setBool(AppStrings.isLogIn, true);
                setState(() {
                  isCashEnable = true;
                  localLocation = model!.locations;
                });
              }
            }
          }
        },
      );
    }
  }

  Future<bool> startImportAndNavigate() async {
    bool result = false;
    pref = spEngine!.prefs;
    try {
      bool isUpdate = pref!.getBool(AppStrings.isUpdate) ?? false;
      if (!isUpdate) {
        bool success = await model!.initLocalData();
        if (!context.mounted) return result;

        if (success) {
          pref!.setBool(AppStrings.isUpdate, true);
          result = true;
        }
      }
    } catch (e) {
      throw Exception(e.toString());
    }
    return result;
  }

  void validateCashInput([BuildContext? context]) async {
    if (formKey.currentState!.validate()) {
      await model!
          .cashRegisterApi(
              amt: cashCtrl.text,
              locationId: locationId,
              context: context!,
              key: keyLoader)
          .then(
        (value) {
          if (value) {
            if (value) {
              Navigator.of(context).pushNamedAndRemoveUntil(
                "/Dashboard",
                (route) => false,
              );
            }
          }
        },
      );
    }
  }

  void isLoad() {
    pref = spEngine!.prefs;
    String? permittedList = pref?.getString(AppStrings.locationsList);
    if (permittedList != null) {
      List<dynamic> decodedList = jsonDecode(permittedList);
      List<Locations> mainList =
          decodedList.map((e) => Locations.fromJson(e)).toList();
      if (mainList.length == 1) {
        setState(() {
          locationId = mainList[0].id ?? 0;
          isLocation = true;
        });
      } else {
        setState(() {
          localLocation = mainList;
        });
      }
    }
    bool isLog =
        pref == null ? false : pref!.getBool(AppStrings.isLogIn) ?? false;
    setState(() {
      isCashEnable = isLog;
    });
  }
}

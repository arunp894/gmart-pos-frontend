import 'dart:isolate';
import 'dart:io';
import 'package:excel/excel.dart';
import 'package:sqflite/sqflite.dart';
import 'package:gmart/Core/application_base.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

class ImportRequest {
  final String filePath;
  final SendPort sendPort;

  ImportRequest(this.filePath, this.sendPort);
}

/// ✅ Top-level function that runs in an isolate
Future<void> _importIsolate(ImportRequest request) async {
  bool result = false;
  try {
    // ✅ REQUIRED INSIDE ISOLATE
    sqfliteFfiInit();
    databaseFactory = databaseFactoryFfi;
    final bytes = await File(request.filePath).readAsBytes();
    final excel = Excel.decodeBytes(bytes);

    var databasesPath = await getDatabasesPath();
    String path = "$databasesPath/pos.db";
    Database db = await openDatabase(
      path,
      version: 1,
      onConfigure: (db) async {
        await db.execute("PRAGMA foreign_keys = ON");
      },
    );

    final categorySheet = excel.sheets["Worksheet"];
    final variantSheet = excel.sheets["Worksheet 2"];
    final productSheet = excel.sheets["Worksheet 1"];

    // if (categorySheet != null && variantSheet != null && productSheet != null) {
    //   if (await categoryDataImport(db: db, sheetData: categorySheet) &&
    //       await variantDataImport(db: db, sheetData: variantSheet) &&
    //       await productDataImport(db: db, sheetData: productSheet)) {
    //     result = true;
    //   }
    // }
    await db.close();
  } catch (e) {
    result = false;
  }

  // Send result back to main thread
  request.sendPort.send(result);
}

Future<bool> runBackgroundImport(String filePath) async {
  final receivePort = ReceivePort();

  await Isolate.spawn(
    _importIsolate,
    ImportRequest(filePath, receivePort.sendPort),
  );

  // Wait for result from isolate
  final result = await receivePort.first as bool;
  return result;
}


